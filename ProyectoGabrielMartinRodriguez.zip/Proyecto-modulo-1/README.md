# Proyecto modulo 1.

Proyecto para el modulo de diseño web con HTML, CSS y Javascript. 
Creacion de una pagina web responsive que incorpore los conceptos vistos en clase. 

Se trata de una landing page para una tienda de plantas de interior. 
